# Additional built-in functions
