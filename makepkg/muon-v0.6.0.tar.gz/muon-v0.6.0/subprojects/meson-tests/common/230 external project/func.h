int func(void);
